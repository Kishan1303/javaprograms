/*
	WAP to create package name with human create a class student, developer and hobbies use access 
	specifiers private, public and protected also use thread and create a member of them and 
	inherit all above class also use interface for student class 
	access specifiers, abstract, interface, inherit, package, thread
*/
import human.packAll;
public class all{
	public static void main(String[] args)
	{
		packAll pa = new packAll();
		pa.packageUse();
	}
}